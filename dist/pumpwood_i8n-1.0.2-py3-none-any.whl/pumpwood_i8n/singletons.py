"""Instanciate an object to be initializated."""
from pumpwood_i8n.translate import PumpwoodI8n

# Instanciate an object to be initializated at application
pumpwood_i8n = PumpwoodI8n()
